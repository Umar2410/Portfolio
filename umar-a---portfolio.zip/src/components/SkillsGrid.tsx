import { motion } from "motion/react";
import { Terminal, BarChart3, Database, Cloud } from "lucide-react";
import { SKILLS_DATA } from "../data";

export default function SkillsGrid() {
  // Map categories to professional styling & icons
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Programming":
        return <Terminal className="w-5 h-5 text-blue-400" />;
      case "Data Analytics":
        return <BarChart3 className="w-5 h-5 text-purple-400" />;
      case "Database":
        return <Database className="w-5 h-5 text-cyan-400" />;
      case "Tools & Platforms":
        return <Cloud className="w-5 h-5 text-emerald-400" />;
      default:
        return <Terminal className="w-5 h-5 text-blue-400" />;
    }
  };

  const getCategoryTheme = (category: string) => {
    switch (category) {
      case "Programming":
        return "border-blue-500/10 hover:border-blue-500/30 shadow-blue-500/5";
      case "Data Analytics":
        return "border-purple-500/10 hover:border-purple-500/30 shadow-purple-500/5";
      case "Database":
        return "border-cyan-500/10 hover:border-cyan-500/30 shadow-cyan-500/5";
      case "Tools & Platforms":
        return "border-emerald-500/10 hover:border-emerald-500/30 shadow-emerald-500/5";
      default:
        return "border-blue-500/10 hover:border-blue-500/30 shadow-blue-500/5";
    }
  };

  const getProgressColor = (category: string) => {
    switch (category) {
      case "Programming":
        return "bg-gradient-to-r from-blue-600 to-cyan-500 shadow-[0_0_12px_rgba(59,130,246,0.5)]";
      case "Data Analytics":
        return "bg-gradient-to-r from-purple-600 to-pink-500 shadow-[0_0_12px_rgba(139,92,246,0.5)]";
      case "Database":
        return "bg-gradient-to-r from-cyan-600 to-teal-500 shadow-[0_0_12px_rgba(6,182,212,0.5)]";
      case "Tools & Platforms":
        return "bg-gradient-to-r from-emerald-600 to-teal-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]";
      default:
        return "bg-gradient-to-r from-blue-600 to-purple-600";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto relative z-10">
      {SKILLS_DATA.map((cat, catIdx) => (
        <motion.div
          key={cat.category}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6, delay: catIdx * 0.1 }}
          className={`p-6 sm:p-8 rounded-2xl glass-panel border ${getCategoryTheme(
            cat.category
          )} hover:shadow-2xl transition-all duration-300 relative overflow-hidden group`}
        >
          {/* Futuristic ambient light inside card */}
          <div className="absolute -top-12 -right-12 w-32 h-32 bg-white/2 rounded-full blur-3xl group-hover:bg-white/5 transition-colors duration-500" />

          {/* Card Header Category */}
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-white/5 rounded-xl border border-white/10 group-hover:border-white/20 transition-all duration-300">
              {getCategoryIcon(cat.category)}
            </div>
            <div>
              <span className="text-xs font-mono tracking-widest text-neutral-500 uppercase">
                Category
              </span>
              <h3 className="text-lg font-display font-semibold text-white">
                {cat.category}
              </h3>
            </div>
          </div>

          {/* Interactive Skill Progress Bars */}
          <div className="space-y-5">
            {cat.skills.map((skill) => (
              <div key={skill.name} className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium text-neutral-300 hover:text-white transition-colors">
                    {skill.name}
                  </span>
                  <span className="font-mono text-xs text-neutral-400">
                    {skill.level}%
                  </span>
                </div>
                
                {/* Outlined track */}
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: 0.2 }}
                    className={`h-full rounded-full ${getProgressColor(cat.category)}`}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
}
