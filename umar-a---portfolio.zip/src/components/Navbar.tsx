import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Cpu, Github, Linkedin, Mail } from "lucide-react";
import { CONTACT_DATA } from "../data";

const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Education", href: "#education" },
  { label: "Certifications", href: "#certifications" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [activeTab, setActiveTab] = useState("Home");
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);

      // Detect active section
      const scrollPosition = window.scrollY + 200;
      for (const link of NAV_LINKS) {
        const targetId = link.href.slice(1);
        const element = document.getElementById(targetId);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveTab(link.label);
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-40 transition-all duration-300 ${
          isScrolled
            ? "py-3 bg-cyber-dark/80 backdrop-blur-md border-b border-white/5"
            : "py-5 bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:shadow-purple-500/30 transition-all duration-300">
              <Cpu className="w-5 h-5 text-white group-hover:rotate-12 transition-transform duration-300" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight bg-gradient-to-r from-white via-neutral-200 to-neutral-400 bg-clip-text text-transparent">
              UMAR <span className="text-blue-400">.A</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-sm">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setActiveTab(link.label)}
                className={`relative px-4 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                  activeTab === link.label
                    ? "text-white"
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                {activeTab === link.label && (
                  <motion.div
                    layoutId="active-nav-indicator"
                    className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full -z-10"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
                {link.label}
              </a>
            ))}
          </nav>

          {/* Quick Contacts Desktop */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={CONTACT_DATA.github}
              target="_blank"
              rel="noreferrer"
              className="p-2 text-neutral-400 hover:text-white hover:bg-white/5 rounded-full transition-colors duration-200"
              title="GitHub"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href={CONTACT_DATA.linkedin}
              target="_blank"
              rel="noreferrer"
              className="p-2 text-neutral-400 hover:text-white hover:bg-white/5 rounded-full transition-colors duration-200"
              title="LinkedIn"
            >
              <Linkedin className="w-4 h-4" />
            </a>
            <a
              href={`mailto:${CONTACT_DATA.email}`}
              className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-500/20 hover:border-transparent transition-all duration-300 shadow-lg hover:shadow-blue-500/20"
            >
              Hire Me
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-neutral-400 hover:text-white bg-white/5 rounded-lg border border-white/10"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed top-20 left-4 right-4 z-40 lg:hidden p-6 rounded-2xl glass-panel border border-white/10 shadow-2xl"
          >
            <nav className="flex flex-col gap-3">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => {
                    setActiveTab(link.label);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    activeTab === link.label
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                      : "text-neutral-300 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  {link.label}
                </a>
              ))}
            </nav>

            <div className="h-px bg-white/10 my-5" />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <a
                  href={CONTACT_DATA.github}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 text-neutral-300 hover:text-white bg-white/5 rounded-full"
                >
                  <Github className="w-4 h-4" />
                </a>
                <a
                  href={CONTACT_DATA.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 text-neutral-300 hover:text-white bg-white/5 rounded-full"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
                <a
                  href={`mailto:${CONTACT_DATA.email}`}
                  className="p-2 text-neutral-300 hover:text-white bg-white/5 rounded-full"
                >
                  <Mail className="w-4 h-4" />
                </a>
              </div>
              <a
                href={`mailto:${CONTACT_DATA.email}`}
                className="px-5 py-2 rounded-xl text-xs font-semibold text-center bg-blue-600 text-white shadow-lg shadow-blue-500/25 block"
                onClick={() => setMobileMenuOpen(false)}
              >
                Hire Umar A
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
