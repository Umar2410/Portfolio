import React, { useState } from "react";
import { motion } from "motion/react";
import { Mail, Phone, MapPin, Copy, Check, Send, Linkedin, Github } from "lucide-react";
import { CONTACT_DATA } from "../data";

export default function ContactForm() {
  const [formData, setFormData] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Simulate real high-tech backend processing
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      setFormData({ name: "", email: "", subject: "", message: "" });
      setTimeout(() => setSubmitted(false), 5000);
    }, 1500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-5xl mx-auto relative z-10">
      {/* Left Column: Direct info nodes (5 spans) */}
      <div className="lg:col-span-5 space-y-6">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="p-6 sm:p-8 rounded-2xl glass-panel border border-white/5 space-y-6 shadow-xl"
        >
          <div>
            <h3 className="text-xl font-display font-bold text-white mb-2">
              Recruiter Connection Point
            </h3>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Have an open opportunity or analytics project? Reach out directly. I usually respond within less than 2 hours.
            </p>
          </div>

          <div className="space-y-4">
            {/* Email item */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-white/3 border border-white/5 group hover:border-blue-500/20 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400 group-hover:scale-110 transition-transform">
                  <Mail className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span className="block text-[10px] font-mono tracking-wider text-neutral-500 uppercase">
                    Email Address
                  </span>
                  <a href={`mailto:${CONTACT_DATA.email}`} className="text-sm text-neutral-200 font-medium hover:text-white transition-colors">
                    {CONTACT_DATA.email}
                  </a>
                </div>
              </div>
              <button
                onClick={() => handleCopy(CONTACT_DATA.email, "email")}
                className="p-2 hover:bg-white/5 rounded-lg text-neutral-400 hover:text-white transition-colors"
                title="Copy Email"
              >
                {copiedField === "email" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* Phone item */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-white/3 border border-white/5 group hover:border-purple-500/20 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-400 group-hover:scale-110 transition-transform">
                  <Phone className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span className="block text-[10px] font-mono tracking-wider text-neutral-500 uppercase">
                    Call / WhatsApp
                  </span>
                  <a href={`tel:${CONTACT_DATA.phone}`} className="text-sm text-neutral-200 font-medium hover:text-white transition-colors">
                    {CONTACT_DATA.phone}
                  </a>
                </div>
              </div>
              <button
                onClick={() => handleCopy(CONTACT_DATA.phone, "phone")}
                className="p-2 hover:bg-white/5 rounded-lg text-neutral-400 hover:text-white transition-colors"
                title="Copy Phone Number"
              >
                {copiedField === "phone" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* Location item */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-white/3 border border-white/5 group hover:border-cyan-500/20 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 group-hover:scale-110 transition-transform">
                  <MapPin className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span className="block text-[10px] font-mono tracking-wider text-neutral-500 uppercase">
                    Location
                  </span>
                  <span className="text-sm text-neutral-300 font-medium">
                    {CONTACT_DATA.location}
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleCopy(CONTACT_DATA.location, "loc")}
                className="p-2 hover:bg-white/5 rounded-lg text-neutral-400 hover:text-white transition-colors"
                title="Copy Location"
              >
                {copiedField === "loc" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="h-px bg-white/10" />

          {/* Connect columns */}
          <div className="flex items-center justify-around">
            <a
              href={CONTACT_DATA.linkedin}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-xs font-mono font-bold text-neutral-400 hover:text-white p-2 rounded-lg hover:bg-white/5 transition-all"
            >
              <Linkedin className="w-4.5 h-4.5 text-blue-400" />
              LinkedIn Profile
            </a>
            <a
              href={CONTACT_DATA.github}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-xs font-mono font-bold text-neutral-400 hover:text-white p-2 rounded-lg hover:bg-white/5 transition-all"
            >
              <Github className="w-4.5 h-4.5 text-white" />
              GitHub Profile
            </a>
          </div>
        </motion.div>
      </div>

      {/* Right Column: Interaction form (7 spans) */}
      <div className="lg:col-span-7">
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="p-6 sm:p-8 rounded-2xl glass-panel border border-white/5 shadow-xl relative"
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5 text-left">
                <label htmlFor="name" className="block text-xs font-semibold text-neutral-400">
                  Full Name
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  placeholder="e.g. Sarah Connor"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 focus:border-blue-500 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 outline-none transition-all"
                />
              </div>

              <div className="space-y-1.5 text-left">
                <label htmlFor="email" className="block text-xs font-semibold text-neutral-400">
                  Work Email
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  placeholder="e.g. sarah@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 focus:border-blue-500 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 outline-none transition-all"
                />
              </div>
            </div>

            <div className="space-y-1.5 text-left">
              <label htmlFor="subject" className="block text-xs font-semibold text-neutral-400">
                Subject
              </label>
              <input
                type="text"
                id="subject"
                required
                placeholder="e.g. Technical Interview Opportunity"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                className="w-full bg-white/5 border border-white/10 focus:border-blue-500 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 outline-none transition-all"
              />
            </div>

            <div className="space-y-1.5 text-left">
              <label htmlFor="message" className="block text-xs font-semibold text-neutral-400">
                Your Message
              </label>
              <textarea
                id="message"
                required
                rows={5}
                placeholder="Describe your project size, company, or recruitment requirements here..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full bg-white/5 border border-white/10 focus:border-blue-500 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 outline-none transition-all resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-sm font-semibold text-white transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 font-display cursor-pointer"
            >
              {submitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Securing channel...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Send Instant Dispatch
                </>
              )}
            </button>
          </form>

          {/* Success Indicator overlay */}
          {submitted && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute inset-0 bg-cyber-dark/95 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6 rounded-2xl z-20 border border-emerald-500/20"
            >
              <div className="w-14 h-14 rounded-full bg-emerald-500/15 flex items-center justify-center text-emerald-400 mb-4 animate-bounce">
                <Check className="w-7 h-7" />
              </div>
              <h4 className="text-lg font-display font-medium text-white mb-1">
                Message Dispatched Successfully!
              </h4>
              <p className="text-xs text-neutral-400 max-w-sm">
                Thank you for reaching out to Umar A. A highly secured data copy has been stored. A human response will follow shortly.
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
