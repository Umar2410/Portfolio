import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "motion/react";
import { STATISTICS_DATA } from "../data";

function CountingNumber({ value }: { value: string }) {
  const [current, setCurrent] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.5 });

  // Extract raw numerical values (e.g., "8000" from "8000+", "8.0" from "8.0")
  const numericPart = parseFloat(value.replace(/[^0-9.]/g, ""));
  const nonNumericPart = value.replace(/[0-9.]/g, "");

  useEffect(() => {
    if (!isInView) return;

    let start = 0;
    const end = numericPart;
    if (isNaN(end)) return;

    // Fast animation spacing
    const duration = 1500;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Easing out quadratic
      const easeProgress = progress * (2 - progress);
      const val = start + easeProgress * (end - start);

      if (value.includes(".")) {
        setCurrent(parseFloat(val.toFixed(1)));
      } else {
        setCurrent(Math.floor(val));
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [isInView, numericPart, value]);

  return (
    <span ref={ref} className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight">
      {current}
      {nonNumericPart}
    </span>
  );
}

export default function StatsSection() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mt-16 max-w-5xl mx-auto relative z-10">
      {STATISTICS_DATA.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: i * 0.1 }}
          className="glass-panel p-6 sm:p-8 rounded-2xl flex flex-col justify-between hover:border-blue-500/20 transition-all duration-300 relative overflow-hidden group"
        >
          {/* Subtle gradient light */}
          <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-colors duration-300" />
          
          <div className="mb-2">
            <CountingNumber value={stat.count} />
            {stat.suffix && (
              <span className="text-neutral-500 font-display text-sm ml-1 select-none">
                {stat.suffix}
              </span>
            )}
          </div>
          <span className="text-neutral-400 text-xs sm:text-sm font-medium leading-relaxed">
            {stat.label}
          </span>
        </motion.div>
      ))}
    </div>
  );
}
