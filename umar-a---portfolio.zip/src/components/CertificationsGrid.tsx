import { motion } from "motion/react";
import { Award, ShieldCheck, ArrowUpRight } from "lucide-react";
import { CERTIFICATIONS_DATA } from "../data";

export default function CertificationsGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto relative z-10">
      {CERTIFICATIONS_DATA.map((cert, idx) => {
        return (
          <motion.div
            key={cert.name}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.4, delay: idx * 0.08 }}
            className="group relative p-5 rounded-2xl glass-panel border border-white/5 hover:border-purple-500/20 hover:shadow-lg hover:shadow-purple-500/5 transition-all duration-300 overflow-hidden flex flex-col justify-between"
          >
            {/* Top right indicator */}
            <div className="absolute top-4 right-4 text-neutral-600 group-hover:text-purple-400 transition-colors">
              <ArrowUpRight className="w-4 h-4" />
            </div>

            {/* Glowing spot background */}
            <div className="absolute top-0 left-0 w-16 h-16 bg-purple-500/5 rounded-full blur-xl group-hover:bg-purple-500/10 transition-colors" />

            <div className="space-y-4 relative z-10">
              {/* Badge Icon */}
              <div className="w-10 h-10 rounded-lg bg-pink-500/10 flex items-center justify-center border border-pink-500/20 group-hover:scale-110 transition-transform duration-300">
                <Award className="w-5 h-5 text-pink-400" />
              </div>

              {/* Certification Name and Issuer */}
              <div className="space-y-1">
                <h4 className="font-display font-semibold text-white group-hover:text-blue-400 transition-colors duration-200 text-sm leading-snug">
                  {cert.name}
                </h4>
                <p className="text-xs font-mono text-neutral-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  Verified on {cert.provider}
                </p>
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
