import { motion } from "motion/react";
import { Briefcase, Calendar, CheckCircle2 } from "lucide-react";
import { EXPERIENCE_DATA } from "../data";

export default function ExperienceTimeline() {
  return (
    <div className="max-w-4xl mx-auto relative z-10">
      {/* Central Timeline Spine line (visible on md screens and above) */}
      <div className="absolute left-8 lg:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-blue-500 via-purple-500 to-transparent z-0 hidden md:block" />

      <div className="space-y-12">
        {EXPERIENCE_DATA.map((exp, idx) => {
          const isEven = idx % 2 === 0;

          return (
            <motion.div
              key={exp.company}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              className={`flex flex-col md:flex-row relative items-start md:items-center ${
                isEven ? "md:flex-row-reverse" : ""
              }`}
            >
              {/* Central Glowing Icon Dot */}
              <div className="absolute left-8 lg:left-1/2 w-6 h-6 rounded-full bg-cyber-dark border-2 border-purple-500 -translate-x-1/2 shadow-lg shadow-purple-500/20 z-10 hidden md:flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              </div>

              {/* Spacer on the alternate side to create alternating columns */}
              <div className="w-full md:w-1/2 hidden md:block" />

              {/* Card Container */}
              <div className="w-full md:w-[46%] pl-12 md:pl-0">
                <div className="p-6 sm:p-8 rounded-2xl glass-panel relative overflow-hidden group border border-white/5 hover:border-blue-500/30 transition-all duration-300 shadow-xl">
                  {/* Accent Gradient Band */}
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b from-blue-500 to-purple-500" />
                  
                  {/* Corner ambient orb */}
                  <div className="absolute -bottom-10 -right-10 w-28 h-28 bg-purple-500/5 rounded-full blur-2xl group-hover:bg-purple-500/10 transition-colors duration-300" />

                  {/* Date & Briefcase Row */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                    <span className="flex items-center gap-1.5 text-xs font-mono text-cyan-400">
                      <Calendar className="w-3.5 h-3.5" />
                      {exp.period}
                    </span>
                    <span className="flex items-center gap-1 text-xs font-mono text-neutral-500">
                      <Briefcase className="w-3.5 h-3.5" />
                      Internship
                    </span>
                  </div>

                  {/* Role Title */}
                  <h3 className="text-xl font-display font-bold text-white group-hover:text-blue-400 transition-colors duration-200">
                    {exp.role}
                  </h3>
                  {/* Company Name */}
                  <p className="text-sm font-medium text-neutral-400 mb-5">
                    {exp.company}
                  </p>

                  {/* Bullet Highlights */}
                  <ul className="space-y-3 mb-6">
                    {exp.points.map((pt, pIdx) => (
                      <li key={pIdx} className="flex items-start gap-2.5 text-sm text-neutral-300 leading-relaxed">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Technology badging */}
                  <div className="flex flex-wrap gap-2 pt-2 border-t border-white/5">
                    {exp.techUsed.map((tech) => (
                      <span
                        key={tech}
                        className="px-2.5 py-1 rounded-md text-xs font-mono bg-white/5 border border-white/10 text-neutral-300 group-hover:border-blue-500/20 group-hover:bg-blue-500/5 transition-all"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
