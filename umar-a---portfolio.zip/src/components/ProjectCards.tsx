import { motion } from "motion/react";
import { Github, Folder, ExternalLink, Sparkles, Database, Image as ImageIcon } from "lucide-react";
import { PROJECTS_DATA } from "../data";

export default function ProjectCards() {
  return (
    <div className="space-y-10 max-w-5xl mx-auto relative z-10">
      {PROJECTS_DATA.map((project, idx) => {
        const isAI = project.title.toLowerCase().includes("ai");

        return (
          <motion.div
            key={project.title}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7, delay: idx * 0.1 }}
            className="group relative rounded-3xl p-6 sm:p-8 lg:p-10 glass-panel border border-white/5 hover:border-blue-500/20 transition-all duration-300 shadow-2xl overflow-hidden"
          >
            {/* Core background glowing orb, blue for Data, purple for AI */}
            <div
              className={`absolute -bottom-20 -right-20 w-80 h-80 rounded-full blur-[140px] opacity-10 group-hover:opacity-20 transition-all duration-500 ${
                isAI ? "bg-purple-600" : "bg-blue-600"
              }`}
            />

            {/* Split layout: Header-meta left, content right */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
              {/* Left visual badge card column (4 spans) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-2xl bg-white/5 border border-white/10 ${isAI ? "text-purple-400" : "text-blue-400"}`}>
                    {isAI ? <ImageIcon className="w-6 h-6" /> : <Database className="w-6 h-6" />}
                  </div>
                  <span className="text-xs font-mono tracking-widest text-[#8b5cf6] uppercase flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    {isAI ? "Machine Learning" : "Data Analysis"}
                  </span>
                </div>

                <h3 className="text-2xl font-display font-bold text-white group-hover:text-blue-400 transition-colors duration-200 leading-tight">
                  {project.title}
                </h3>

                {/* Tech tag cluster */}
                <div className="flex flex-wrap gap-2 pt-2">
                  {project.tech.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 text-xs font-mono rounded-lg bg-white/5 border border-white/10 text-neutral-300"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Github Link Trigger */}
                <div className="pt-4">
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 text-xs font-mono font-bold text-neutral-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2.5 rounded-xl transition-all"
                  >
                    <Github className="w-4 h-4" />
                    Source Code
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Right description points column (8 spans) */}
              <div className="lg:col-span-8 lg:border-l lg:border-white/10 lg:pl-8 space-y-4">
                <h4 className="text-xs font-mono tracking-widest text-neutral-500 uppercase flex items-center gap-2">
                  <Folder className="w-4 h-4 text-blue-400/80" />
                  Key Achievements & Implementation
                </h4>
                <div className="space-y-3">
                  {project.description.map((bullet, bIdx) => (
                    <p
                      key={bIdx}
                      className="text-sm text-neutral-300 leading-relaxed font-sans relative before:content-[''] before:absolute before:-left-4 before:top-2.5 before:w-1.5 before:h-1.5 before:rounded-full before:bg-blue-400/60 pl-4"
                    >
                      {bullet}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
