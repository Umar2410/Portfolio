import { motion } from "motion/react";
import { GraduationCap, Landmark, Calendar, Award } from "lucide-react";
import { EDUCATION_DATA } from "../data";

export default function EducationTimeline() {
  return (
    <div className="max-w-4xl mx-auto relative z-10">
      {/* Visual background timeline trace */}
      <div className="absolute left-8 lg:left-1/2 top-4 bottom-4 w-px bg-gradient-to-b from-blue-500/50 via-purple-500/50 to-transparent hidden md:block" />

      <div className="space-y-10">
        {EDUCATION_DATA.map((edu, idx) => {
          const isEven = idx % 2 === 0;

          return (
            <motion.div
              key={edu.degree}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className={`flex flex-col md:flex-row relative items-start md:items-center ${
                isEven ? "md:flex-row-reverse" : ""
              }`}
            >
              {/* Timeline Center Badge */}
              <div className="absolute left-8 lg:left-1/2 w-8 h-8 rounded-xl bg-cyber-deep border border-neutral-700 -translate-x-1/2 shadow-lg z-10 hidden md:flex items-center justify-center text-blue-400">
                <GraduationCap className="w-4 h-4" />
              </div>

              {/* Spatial Spacer */}
              <div className="w-full md:w-1/2 hidden md:block" />

              {/* Education Block Card */}
              <div className="w-full md:w-[46%] pl-12 md:pl-0">
                <div className="p-6 sm:p-8 rounded-2xl glass-panel relative overflow-hidden group hover:border-purple-500/30 transition-all duration-300">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/3 rounded-full blur-2xl pointer-events-none" />

                  {/* Period & Institution Info */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                    <span className="flex items-center gap-1.5 text-xs font-mono text-cyan-400">
                      <Calendar className="w-3.5 h-3.5" />
                      {edu.period}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs font-mono text-neutral-500 uppercase">
                      <Landmark className="w-3.5 h-3.5" />
                      Degrees
                    </span>
                  </div>

                  <h3 className="text-lg font-display font-bold text-white group-hover:text-purple-400 transition-colors">
                    {edu.degree}
                  </h3>
                  
                  <p className="text-sm text-neutral-400 mt-1 mb-5">
                    {edu.institution}
                  </p>

                  {/* Numerical Achievement Tag */}
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono text-xs font-semibold uppercase">
                    <Award className="w-4 h-4" />
                    {edu.score}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
